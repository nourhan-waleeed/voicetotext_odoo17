odoo.define('dhs_voice_to_text.onClickIconMicrophone',[] ,function (require) {
  "use strict";

    function insertIconIfMissing() {
        $.getJSON("/dhs_voice_to_text/get_voice_to_text_status", function(data) {
            if(data.voice_to_text_enable)
            {
                $("div input.o_input").each(function() {
                    const $input = $(this);
                    
                    // Check if the input has the o_invisible_modifier class
                    if (!$input.hasClass('o_address_zip') && !$input.hasClass('o_invisible_modifier') && !$input.hasClass('o_address_city') && !$input.hasClass('o_address_zip') && !$input.hasClass('o_address_street')) {
                        const $nextElement = $input.next();
                        
                        if (!$nextElement.hasClass('fa-microphone') && !$nextElement.hasClass('fa-microphone-slash')) {
                            const $newIcon = $('<i>').addClass('fa fa-microphone iconclick'); // Add your desired icon classes here
                            $newIcon.css({
                                position: 'absolute',
                                right: '13%', // Adjust the left position as needed
                                top: '25%',   // Adjust the top position as needed
                            });
                            $('div.o_field_widget').css({position:'relative'});
                            $('div.o_searchview_input_container').css({position:'relative'});
                            
                            $input.after($newIcon);
                        }
                    }
                });
            }
            else
            {
                $('button.o_Composer_buttonMicrophone').hide(); 
            }
        });
    }


    // Insert the icon initially
    // insertIconIfMissing();

    // Periodically check for the presence of the icon
    setInterval(insertIconIfMissing, 1000); // Adjust the interval as needed


    // Initialize a variable to store the recognized speech text
    var recognizedText = "";

    //voice to text function
    $(document).on('click', '.iconclick', function(e){

      
      const info = $(".info");

      // text box selector
      const searchFormInput = $(this).prev();

      // The speech recognition interface lives on the browser’s window object
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition; // if none exists -> undefined
      const micIcon = $(this);

      if(SpeechRecognition) {
          console.log("Your Browser supports speech Recognition");
          if (micIcon.hasClass("fa-microphone")) {
              self.recognition = new SpeechRecognition();
              self.recognition.continuous = true;
              self.recognition.start();
          } else if (micIcon.hasClass("fa-microphone-slash")) {
              return self.recognition.stop();
          }

          function startSpeechRecognition() {
              micIcon.removeClass("fa-microphone");
              micIcon.addClass("fa-microphone-slash");

              searchFormInput.focus();

              console.log("Voice activated, SPEAK");
              console.log("text box js call........");
          }

          function endSpeechRecognition() {
              micIcon.removeClass("fa-microphone-slash");
              micIcon.addClass("fa-microphone");

              searchFormInput.focus();

              console.log("Speech recognition disconnected");
          }

        function resultOfSpeechRecognition(event) {
            const current = event.resultIndex;
            var transcript = event.results[current][0].transcript;


            if (transcript[transcript.length-1] === ".") {
                transcript = transcript.slice(0,-1);
            }

            recognizedText = transcript; // Store the recognized text

            // Update the input field with the recognized text
            searchFormInput.val(recognizedText);
            searchFormInput.trigger('input').trigger('change');
          }

          if(self.recognition){
            self.recognition.addEventListener("start", startSpeechRecognition.bind(self));
            self.recognition.addEventListener("end", endSpeechRecognition.bind(self));
            self.recognition.addEventListener("result", resultOfSpeechRecognition.bind(self));
          }
      } else {
          if (info) {
              info.val("Your Browser does not support Speech Recognition");
          }
      }
  });
});


