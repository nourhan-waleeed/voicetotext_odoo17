from odoo import models, fields, api, _

class CustomSettings(models.TransientModel):
    _inherit = 'res.config.settings'
    
    voice_to_text_enable = fields.Boolean(string="Enable Voice To Text",config_parameter='dhs_voice_to_text.voice_to_text_enable')

    
    