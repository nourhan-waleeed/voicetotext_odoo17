from odoo import http
from odoo.http import request
import json

class VoiceToTextController(http.Controller):

    @http.route('/dhs_voice_to_text/get_voice_to_text_status', type='http', auth='user', website=True)
    def get_voice_to_text_status(self):
        voice_to_text_enable = request.env['ir.config_parameter'].sudo().get_param('dhs_voice_to_text.voice_to_text_enable', default=False)
        return json.dumps({'voice_to_text_enable': voice_to_text_enable})

