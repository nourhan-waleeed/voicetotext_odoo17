{
    "name": "Odoo Voice to Text",
	'version': '17.0.0.0',
	'category': 'Extra Tools',
    "summary": "Odoo Voice to Text",
    "description": "Unlock the power of seamless communication and productivity with our cutting-edge Voice to Text application. Watch your spoken words transform into written magic, making your life easier and more efficient than ever before. Experience the future of transcription and text input. Just speak, and let technology do the rest!",
    'author': 'Doyenhub Software Solution',
    'company': 'Doyenhub Software Solution',
    'maintainer': 'Doyenhub Software Solution',
    'website':'https://www.doyenhub.com/',
	"price": 39,
	"currency": 'USD',
    "depends": ["mail", "web"],
    "data": [
        'views/setting_inherit_view.xml',
        'data/defult_true.xml'
    ],
    "demo": [],
    "assets": {
        'mail.assets_core_messaging': [
            'dhs_voice_to_text/static/src/js/speech.js',
        ],
        'web.assets_backend': [
            # 'dhs_voice_to_text/static/src/components/*/*.xml',
            'dhs_voice_to_text/static/src/js/textbox.js',
            'dhs_voice_to_text/static/src/css/text-box.css',
        ],
    },
    'live_test_url':'https://youtu.be/IObCSK5fGo4',
    'installable': True,
    'application': False,
    'auto_install': False,
    'images': ["static/description/banner.png"],
    'license': 'OPL-1',
}
